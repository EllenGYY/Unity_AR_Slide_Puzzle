﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonChoice : MonoBehaviour
{
    public Button button4;
	public Button button8;
	public GameObject scaler;
	GameObject newScaler;

    void Start(){
        button4.onClick.AddListener(button4Task);
		button8.onClick.AddListener(button8Task);
    }

    void button4Task(){
		GameObject origin = GameObject.FindWithTag("scaler");
		if(origin != null){
			Destroy(origin);
			GameObject.FindWithTag("timer").GetComponent<UnityEngine.UI.Text>().text = "";
			GameObject.FindWithTag("message").GetComponent<UnityEngine.UI.Text>().text = "";
		}
        newScaler = (GameObject)Instantiate(scaler, new Vector3(0, 0, 0), Quaternion.identity);
    }

	void button8Task(){
		GameObject origin = GameObject.FindWithTag("scaler");
		if(origin != null){
			Destroy(origin);
			GameObject.FindWithTag("timer").GetComponent<UnityEngine.UI.Text>().text = "";
			GameObject.FindWithTag("message").GetComponent<UnityEngine.UI.Text>().text = "";
		}
        newScaler = (GameObject)Instantiate(scaler, new Vector3(0, 0, 0), Quaternion.identity);
		((GameInstant)newScaler.GetComponent(typeof(GameInstant))).isFour = false;
		((CountdownTimer)newScaler.GetComponent(typeof(CountdownTimer))).duration = 25;
    }
}
